package grade;

public class Student {
	private long ID;
	private String LessenName;
	private String LessenType;
	private double Credit;
	private String Teacher;
	private String College;
	private String StudyType;
	private int year;
	private String Term;
	private int Score;
	public Student() {
		super();
	}
	public Student(long ID,String LessenName,String LessenType,double credit,String Teacher,
			String College,String StudyType,int year,String Term,int Score) {
		super();
		this.ID=ID;
		this.LessenName=LessenName;
		this.LessenType=LessenType;
		this.Credit=credit;
		this.Teacher=Teacher;
		this.StudyType=StudyType;
		this.year=year;
		this.Term=Term;
		this.Score=Score;
		this.College=College;
	}
    public void setID(long ID) {
    	this.ID = ID;
    }
    public void setLessonName(String LessenName) {
    	this.LessenName=LessenName;
    }
    public void setLessenType(String LessenType) {
    	this.LessenType=LessenType;
    }
    public void setCredit(double credit) {
    	this.Credit=credit;
    }
    public void setTeacher(String Teacher) {
    	this.Teacher=Teacher;
    }
    public void setStudyType(String StudyType) {
    	this.StudyType=StudyType;
    }
    public void setTerm(String Term) {
    	this.Term=Term;
    }
    public void setScore(int Score) {
    	this.Score=Score;
    }
    public void setCollege(String College) {
    	this.College=College;
    }
    public void setyear(int year) {
    	this.year=year;
    }
    public int getScore(){
    	return Score;
    }
    public long getID(){
    	return ID;
    }
    public String getLessenName(){
    	return LessenName;
    }
    public String getLessenType(){
    	return LessenType;
    }
    public double getCredit(){
    	return Credit;
    }
    public String getTeacher(){
    	return Teacher;
    }
    public int getyear(){
    	return year;
    }
    public String getStudyType(){
    	return StudyType;
    }
    public String getTerm(){
    	return Term;
    }
    public String getCollege(){
    	return College;
    }
}

