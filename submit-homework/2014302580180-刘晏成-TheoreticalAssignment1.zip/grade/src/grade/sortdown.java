package grade;
import java.util.Comparator;

public class sortdown implements Comparator<Student>{
	public int compare(Student a,Student b) {
		int score1=a.getScore();
		int score2=b.getScore();
		if(score1<score2) return 1;
		if(score1>score2) return -1;
		else return 0;
	}

}