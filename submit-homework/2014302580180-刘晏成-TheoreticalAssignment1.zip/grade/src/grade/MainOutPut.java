package grade;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class MainOutPut  {

	public static void main(String[] args) throws IOException {
		HSSFWorkbook wb = new HSSFWorkbook();
		FileOutputStream fileoutputstream = new FileOutputStream("Gradelist.xls");
		HSSFSheet sheet = wb.createSheet("�ɼ���");
		HSSFCellStyle style = wb.createCellStyle();
		int columnCount = 10;
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		//������ͷ
		HSSFRow headRow = sheet.createRow(0);
		String[] titleArray = {"��ͷ��", "�γ�����", "�γ�����", "ѧ��", "��ʦ",
				"�ڿ�ѧԺ", "ѧϰ����", "ѧ��", "ѧ��", "�ɼ�"};
		for(int m=0;m<=columnCount-1;m++)
		{
			HSSFCell cell = headRow.createCell(m);
			HSSFFont font = wb.createFont();
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font.setFontHeightInPoints((short) 12);
			style.setFont(font);
			cell.setCellStyle(style);
			cell.setCellValue(titleArray[m]);
		}
		List<Student> list = getStudent("Grade.xls",0); 
		order(list);
		//��������
		int index = 0;
		for(Student student : list)
		{
			HSSFRow row = sheet.createRow(index+1);
			for(int n=0;n<=columnCount-1;n++)
			{
			row.createCell(n);
			String myID = String.valueOf(student.getID());
			row.getCell(0).setCellValue(myID);
			row.getCell(1).setCellValue(student.getLessenName());
			row.getCell(2).setCellValue(student.getLessenType());
			row.getCell(3).setCellValue(student.getCredit());
			row.getCell(4).setCellValue(student.getTeacher());
			row.getCell(5).setCellValue(student.getCollege());
			row.getCell(6).setCellValue(student.getStudyType());
			row.getCell(7).setCellValue(student.getyear());
			row.getCell(8).setCellValue(student.getTerm());
			row.getCell(9).setCellValue(student.getScore());
			index++;
			}
		}
		wb.write(fileoutputstream);
		fileoutputstream.close();
		wb.close();
	}
	

	
	public static List<Student> getStudent(String file, int ignoreRows)
	       throws FileNotFoundException, IOException  {
		List<Student> result = new ArrayList<Student>();
		int rowSize = 0;
		Student student=null;
		InputStream myExcel = new FileInputStream("Grade.xls");	
		POIFSFileSystem fs = new POIFSFileSystem(myExcel);
		HSSFWorkbook wb = new HSSFWorkbook(fs);
        String cellStr = null;
       
        for (int sheetIndex = 0; sheetIndex < wb.getNumberOfSheets(); sheetIndex++)  {
        	HSSFSheet st = wb.getSheetAt(sheetIndex);
        	
        	for(int rowIndex = ignoreRows; rowIndex <= st.getLastRowNum(); rowIndex++)  {
        		student= new Student();
        		HSSFRow row = st.getRow(rowIndex); 
        		if(row == null) {
        			continue;
        		}
        		 for (int columnIndex = 0; columnIndex < row.getLastCellNum(); columnIndex++) {  
            HSSFCell cell = row.getCell(columnIndex);
               if (cell == null) {
                cellStr = "";  
            } else if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {  
                cellStr = cell.getNumericCellValue() + "";  
            } else {
                cellStr = cell.getStringCellValue();  
            }  
        			if(columnIndex == 0) {
        				student.setID(new Double(cellStr).longValue());
        			}
        			if(columnIndex == 1) {
        				student.setLessonName(cellStr);	
        			}
        			if(columnIndex == 2) {
        				student.setLessenType(cellStr);
        			}
        			if(columnIndex == 3) {
        				student.setCredit(new Double(cellStr).doubleValue());
        			}
        			if(columnIndex == 4) {
        				student.setTeacher(cellStr);
        			}
        			if(columnIndex == 5) {
        				student.setCollege(cellStr);
        			}
        			if(columnIndex == 6) {
        				student.setStudyType(cellStr);
        			}
        			if(columnIndex == 7) {
        				student.setyear(new Double(cellStr).intValue());
        			}
        			if(columnIndex == 8) {
        				student.setTerm(cellStr);
        			}
        			if(columnIndex == 9) {
        				student.setScore(new Double(cellStr).intValue());
        			}
        				}	
        				}
        			}

         result.add(student);
         return result;
	}
	
	public static void order(List<Student> result)  {
		sortdown sd = new sortdown();
		Collections.sort(result,sd);
	}
	public static String rightTrim(String str)  {
		if (str == null) {
			return "";	
		}
		int length = str.length();
		for (int i = length - 1; i >= 0; i--) {
			if (str.charAt(i) != 0x20) {
				break;
			}
			length--;
		}
		return str.substring(0, length);
	}



}

